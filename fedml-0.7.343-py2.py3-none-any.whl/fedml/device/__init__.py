from .device import (
    get_device,
    get_device_type,
)

__all__ = [
    "get_device", "get_device_type"
]

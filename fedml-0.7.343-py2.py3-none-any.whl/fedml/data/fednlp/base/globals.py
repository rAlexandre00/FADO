# Constants

# Data Loader
PAD_TOKEN = "<PAD>"
UNK_TOKEN = "<UNK>"
SOS_TOKEN = "<SOS>"
EOS_TOKEN = "<EOS>"

PAD_LABEL = "O"
UNK_LABEL = "O"

# Partition
N_CLIENTS = 100

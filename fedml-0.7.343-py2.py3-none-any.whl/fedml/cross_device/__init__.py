from .mnn_server import ServerMNN

__all__ = [
    "ServerMNN",
]

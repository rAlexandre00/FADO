import fedml


if __name__ == "__main__":
    fedml.run_cross_silo_server()
